import React, { useState } from 'react';
import './App.css';

function App() {
  const [answers, setAnswers] = useState({
    spicy: null,
    sweet: null,
    savory: null,
    health: null
  });

  const [result, setResult] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setAnswers((prev) => ({ ...prev, [name]: parseInt(value) }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const { spicy, sweet, savory, health } = answers;

    if ([spicy, sweet, savory, health].includes(null)) {
      alert('모든 문항을 선택해주세요.');
      return;
    }

    // 결과 계산 (점수 기반 이진 분기)
    const spicyType = spicy >= 3 ? 'S' : 'M'; // Spicy vs Mild
    const sweetType = sweet >= 3 ? 'W' : 'N'; // Sweet vs Neutral
    const savoryType = savory >= 3 ? 'H' : 'L'; // Heavy vs Light
    const healthType = health >= 3 ? 'C' : 'I'; // Clean vs Indulgent

    const mbti = spicyType + sweetType + savoryType + healthType;
    setResult(mbti);
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">🍽️ 입맛 MBTI 테스트</h1>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* 질문 1 */}
        <div>
          <label className="font-semibold">1. 매운 음식을 얼마나 잘 드시나요?</label>
          <div className="flex gap-4 mt-2">
            {[1, 2, 3, 4].map((val, i) => (
              <label key={i}><input type="radio" name="spicy" value={val} onChange={handleChange} /> {['안 먹어요','조금','보통','좋아해요'][i]}</label>
            ))}
          </div>
        </div>

        {/* 질문 2 */}
        <div>
          <label className="font-semibold">2. 단 음식을 얼마나 즐기나요?</label>
          <div className="flex gap-4 mt-2">
            {[1, 2, 3, 4].map((val, i) => (
              <label key={i}><input type="radio" name="sweet" value={val} onChange={handleChange} /> {['별로 안 좋아해요','조금','보통','엄청 좋아해요'][i]}</label>
            ))}
          </div>
        </div>

        {/* 질문 3 */}
        <div>
          <label className="font-semibold">3. 고소한 음식을 얼마나 선호하나요?</label>
          <div className="flex gap-4 mt-2">
            {[1, 2, 3, 4].map((val, i) => (
              <label key={i}><input type="radio" name="savory" value={val} onChange={handleChange} /> {['별로 안 좋아해요','조금','보통','엄청 좋아해요'][i]}</label>
            ))}
          </div>
        </div>

        {/* 질문 4 */}
        <div>
          <label className="font-semibold">4. 건강한 음식을 얼마나 의식하나요?</label>
          <div className="flex gap-4 mt-2">
            {[1, 2, 3, 4].map((val, i) => (
              <label key={i}><input type="radio" name="health" value={val} onChange={handleChange} /> {['전혀 신경 안 써요','가끔','웬만하면 신경 써요','항상 고려해요'][i]}</label>
            ))}
          </div>
        </div>

        <button type="submit" className="bg-black text-white px-4 py-2 rounded">제출</button>
      </form>

      {result && (
        <div className="mt-8 p-4 bg-gray-100 border rounded text-center">
          <h2 className="text-xl font-bold">🎉 당신의 입맛 MBTI는 <span className="text-blue-600">{result}</span> 입니다!</h2>
          <p className="mt-2">결과에 따라 음식 추천을 받아보세요.</p>
        </div>
      )}
    </div>
  );
}

export default App;
